#ifndef MOVESCRIPT_H
#define MOVESCRIPT_H

#include "./common.h"
#include <vector>

int32 movScriptProcess( std::vector<PathNode>& agvPath, const char* fileName );

#endif // MOVESCRIPT_H
