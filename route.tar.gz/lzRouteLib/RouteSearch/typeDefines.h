#ifndef TYPEDEFINES_H
#define TYPEDEFINES_H
 
typedef float float32;
typedef unsigned char uchar8;
typedef int uint32;
typedef int int32;

//#define PRINT_TYPE QT_PLATFORM

#endif
